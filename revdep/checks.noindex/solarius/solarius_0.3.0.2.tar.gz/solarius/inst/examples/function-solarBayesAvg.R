data(dat30)

M <- solarBaeysAvgPolygenic(traits = "trait1", covlist.test = c("age", "sex"), data = dat30)

